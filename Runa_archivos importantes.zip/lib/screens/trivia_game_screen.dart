// screens/trivia_game_screen.dart
import 'package:flutter/material.dart';
import 'package:runa/models/trivia_model.dart';

class TriviaGameScreen extends StatefulWidget {
  final Trivia trivia;

  const TriviaGameScreen({Key? key, required this.trivia}) : super(key: key);

  @override
  _TriviaGameScreenState createState() => _TriviaGameScreenState();
}

class _TriviaGameScreenState extends State<TriviaGameScreen> {
  int _currentQuestionIndex = 0;
  int _score = 0;

  @override
  Widget build(BuildContext context) {
    final question = widget.trivia.questions[_currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(title: Text(widget.trivia.topic)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(question.text, style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            ...question.options
                .map(
                  (option) => ElevatedButton(
                    onPressed: () => _checkAnswer(option.isCorrect),
                    child: Text(option.text),
                  ),
                )
                .toList(),
            SizedBox(height: 20),
            Text("Puntos: $_score", style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }

  void _checkAnswer(bool isCorrect) {
    setState(() {
      if (isCorrect) _score += 10;
      if (_currentQuestionIndex < widget.trivia.questions.length - 1) {
        _currentQuestionIndex++;
      } else {
        // Fin del juego
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text("¡Trivia completada!"),
            content: Text("Puntuación final: $_score puntos"),
          ),
        );
      }
    });
  }
}
