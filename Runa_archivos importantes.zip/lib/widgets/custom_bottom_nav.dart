import 'package:flutter/material.dart';

class CustomBottomNav extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: CircularNotchedRectangle(),
      notchMargin: 8,
      child: Container(
        height: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: Icon(Icons.assignment, size: 30),
              onPressed: () => print('Ir a Retos'),
            ),
            SizedBox(width: 40), // Espacio para el FAB
            IconButton(
              icon: Icon(Icons.settings, size: 30),
              onPressed: () => print('Ir a Configuración'),
            ),
          ],
        ),
      ),
    );
  }
}
