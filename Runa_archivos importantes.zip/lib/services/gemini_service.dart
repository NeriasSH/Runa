// services/gemini_service.dart
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'dart:convert';
import 'package:runa/models/trivia_model.dart';

class GeminiService {
  static const String _defaultModel = 'gemini-pro';
  late final GenerativeModel _model;
  bool _isInitialized = false;

  GeminiService() {
    _initializeModel();
  }

  Future<void> _initializeModel() async {
    try {
      final apiKey = 'AIzaSyBZxtrJ4vww93JzER2LSE98VQd5dteBRUI';
      _model = GenerativeModel(
        model: _defaultModel,
        apiKey: apiKey,
        generationConfig: GenerationConfig(
          maxOutputTokens: 2000,
          temperature: 0.5,
        ),
      );
      _isInitialized = true;
    } catch (e) {
      throw Exception('Error inicializando Gemini: ${e.toString()}');
    }
  }

  Future<String> _getValidApiKey() async {
    // 1. Intenta cargar variables de entorno si no están cargadas
    try {
      await dotenv.load(fileName: ".env");
    } catch (e) {
      print("Warning: No se pudo cargar .env: ${e.toString()}");
    }

    // 2. Verifica la key de entorno
    final envKey = dotenv.env['GEMINI_API_KEY'];
    if (envKey != null && envKey.isNotEmpty) {
      return envKey;
    }

    // 3. Key hardcodeada SOLO para desarrollo/debug
    const debugKey = 'TU_API_KEY_REAL'; // ¡REEMPLAZA ESTO CON TU KEY REAL!
    if (debugKey.isNotEmpty && !debugKey.contains('TU_API_KEY')) {
      print("Warning: Usando API key de desarrollo");
      return debugKey;
    }

    throw Exception('''
API Key no configurada correctamente. Por favor:

1. Obtén una key válida de Google AI Studio
2. Crea un archivo .env en la raíz de tu proyecto con:
   GEMINI_API_KEY=tu_key_aqui
3. O reemplaza temporalmente 'debugKey' en este archivo
''');
  }

  Future<Trivia> generateTrivia(String topic) async {
    if (!_isInitialized) {
      await _initializeModel();
    }

    final prompt = _buildTriviaPrompt(topic);

    try {
      final response = await _model.generateContent([Content.text(prompt)]);
      final responseText = _cleanGeminiResponse(response.text ?? '');
      return _parseTriviaResponse(responseText);
    } catch (e) {
      throw Exception('''
Error generando trivia para "$topic":
${e.toString()}

Solución:
1. Verifica tu conexión a internet
2. Confirma que la API key sea válida
3. Revisa el formato del prompt''');
    }
  }

  String _buildTriviaPrompt(String topic) {
    return """
    Genera exactamente 1 pregunta sobre '$topic' en formato JSON estricto con:
    - 1 tema principal (campo "topic")
    - 1 pregunta (campo "text")
    - 4 opciones (campo "options"), solo 1 correcta

    Estructura requerida:
    {
      "topic": "[El tema principal]",
      "questions": [
        {
          "text": "[La pregunta]",
          "options": [
            {"text": "[Opción 1]", "isCorrect": true},
            {"text": "[Opción 2]", "isCorrect": false},
            {"text": "[Opción 3]", "isCorrect": false},
            {"text": "[Opción 4]", "isCorrect": false}
          ]
        }
      ]
    }
    """;
  }

  String _cleanGeminiResponse(String response) {
    return response.replaceAll('```json', '').replaceAll('```', '').trim();
  }

  Trivia _parseTriviaResponse(String jsonString) {
    try {
      final jsonMap = jsonDecode(jsonString) as Map<String, dynamic>;
      return Trivia.fromJson(jsonMap);
    } catch (e) {
      throw FormatException('''
Error parseando respuesta de Gemini:
Respuesta original: ${jsonString.length > 100 ? jsonString.substring(0, 100) + '...' : jsonString}
Error: ${e.toString()}''');
    }
  }
}
