class Secrets {
  static const geminiApiKey = String.fromEnvironment('GEMINI_API_KEY');
}
